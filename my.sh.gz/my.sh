#!/bin/bash

# my.sh (Batch Shell Script for rploader.sh)                 
# Made by Peter Suh
# 2022.04.18                      
# Update
# 2022.04.24

mshellgz="my.sh.gz"
mshtarfile="https://raw.githubusercontent.com/PeterSuh-Q3/tinycore-redpill/main/my.sh.gz"

function checkinternet() {

    echo -n "Checking Internet Access -> "
    nslookup github.com 2>&1 >/dev/null
    if [ $? -eq 0 ]; then
        echo "OK"
    else
        echo "Error: No internet found, or github is not accessible"
        exit 99
    fi

}

function getlatestmshell() {

    echo -n "Checking if a newer mshell version exists on the repo -> "

    if [ ! -f $mshellgz ]; then
        curl -s --location "$mshtarfile" --output $mshellgz
    fi

    curl -s --location "$mshtarfile" --output latest.mshell.gz

    CURRENTSHA="$(sha256sum $mshellgz | awk '{print $1}')"
    REPOSHA="$(sha256sum latest.mshell.gz | awk '{print $1}')"

    if [ "${CURRENTSHA}" != "${REPOSHA}" ]; then
        echo -n "There is a newer version of m shell script on the repo should we use that ? [yY/nN]"
        read confirmation
        if [ "$confirmation" = "y" ] || [ "$confirmation" = "Y" ]; then
            echo "OK, updating, please re-run after updating"
            cp -f /home/tc/latest.mshell.gz /home/tc/$mshellgz
            rm -f /home/tc/latest.mshell.gz
            tar -zxvf $mshellgz
            echo "Updating m shell with latest updates"
            exit
        else
            rm -f /home/tc/latest.mshell.gz
            return
        fi
    else
        echo "Version is current"
        rm -f /home/tc/latest.mshell.gz
    fi

}


function macgen() {

    mac2="$(generateMacAddress $1)"

    echo "Mac2 Address for Model $1 : $mac2 "

    macaddress2=$(echo $mac2 | sed -s 's/://g')

    sed -i "/\"extra_cmdline\": {/c\  \"extra_cmdline\": {\"mac2\": \"$macaddress2\",\"netif_num\": \"2\", "  user_config.json
    
    echo "After changing user_config.json"
    cat user_config.json   
}

function generateMacAddress() {
    printf '00:11:32:%02X:%02X:%02X' $((RANDOM % 256)) $((RANDOM % 256)) $((RANDOM % 256))

}


if [ $# -lt 1 ]; then
    echo Please type Synology Model Name after ./m.sh
    exit 99
fi

MODEL=$1

echo MODEL is $MODEL

    if [ "${MODEL}" = "DS918+" ]; then
        TARGET_PLATFORM="apollolake"
    elif [ "${MODEL}" = "DS3615xs" ]; then
        TARGET_PLATFORM="bromolow"
    elif [ "${MODEL}" = "DS3617xs" ]; then
        TARGET_PLATFORM="broadwell"
    elif [ "${MODEL}" = "DS3622xs+" ]; then
        TARGET_PLATFORM="broadwellnk"
    elif [ "${MODEL}" = "DS1621+" ]; then
        TARGET_PLATFORM="v1000"
    elif [ "${MODEL}" = "DVA3221" ]; then
        TARGET_PLATFORM="denverton"
    elif [ "${MODEL}" = "DS920+" ]; then
        TARGET_PLATFORM="geminilake"
    else
        echo "Synology model not supported by TCRP."
        exit 0
    fi

checkinternet
getlatestmshell

tcrppart="$(mount | grep -i optional | grep cde | awk -F / '{print $3}' | uniq | cut -c 1-3)3"
echo tcrppart is $tcrppart                                                  
echo making directory  /mnt/${tcrppart}/auxfiles and make link custom-module                                                  
mkdir /mnt/${tcrppart}/auxfiles                                             
sudo ln -s /mnt/${tcrppart}/auxfiles /home/tc/custom-module 

echo TARGET_PLATFORM is $TARGET_PLATFORM

echo "y"|./rploader.sh update now
echo "n"|./rploader.sh fullupgrade now

echo "Do you want to restore your own user_config.json from old directory ?  [Yy/Nn]"         
read answer                                                                                   
if [ -n "$answer" ] && [ "$answer" = "Y" ] || [ "$answer" = "y" ] ; then                      
    cp -f /home/tc/old/user_config.json.* ./user_config.json                                  
else                                                                                          
    echo "OK Remember that the new user_config.json file is used and your own user_config.json is deleted. "
fi  

echo "Before changing user_config.json" 
cat user_config.json

echo "y"| ./rploader.sh serialgen $MODEL

#check nic count
    let nicport=0                                                                                                                                                 
    lspci -n | while read line; do                                                                                                                  
        class="$(echo $line | cut -c 9-12)"                                                                                                          
                                                                                                                                                     
        #echo "Class : $class"                                                                             
        case $class in                                                                                                                               
        0200)   
            let nicport=$nicport+1                                                                                                                                     
            #echo "Found Ethernet Interface port count: $nicport "       
            if [ $nicport -eq 2 ]; then
               echo "Two or more Ethernet Interface was detected!! $nicport "
               echo "Add mac2 automatically."
               macgen $MODEL
            fi                                                     
      
            ;;                                                                                                                                       
        esac                                                                                                                                         
    done 


echo "y"|./rploader.sh identifyusb now
./rploader.sh satamap now

echo Loader Building in progress...

echo "y"|./rploader.sh build ${TARGET_PLATFORM}-7.1.0-42661                                                                                                                
                                                                                                                                                                           
echo Backup in progress...                                                                                                                                                 
                                                                                                                                                                           
rm -rf /home/tc/old                                                                                                                                                       
rm -rf /home/tc/oldpat.tar.gz                                                                                                                                             
./rploader.sh clean now                                                                                                                                                   
rm -f /mnt/${tcrppart}/auxfiles/*.pat                                                                                                                                          
rm -f /home/tc/custom-module                                                                                                                                             
echo "y"|./rploader.sh backup now                                                                                                                                         
                                          

exit 0
