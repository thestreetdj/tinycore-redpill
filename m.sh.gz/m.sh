#!/bin/bash

if [ $# -lt 1 ]; then
    echo Please type Synology Model Name after ./m.sh 
    exit 99
fi

MODEL=$1

echo MODEL is $MODEL

tcrppart="$(mount | grep -i optional | grep cde | awk -F / '{print $3}' | uniq | cut -c 1-3)3"
echo tcrppart is $tcrppart
echo making directory  /mnt/${tcrppart}/auxfiles and make link custom-module
mkdir /mnt/${tcrppart}/auxfiles 
sudo ln -s /mnt/${tcrppart}/auxfiles /home/tc/custom-module

    if [ "${MODEL}" = "DS918+" ]; then
        TARGET_PLATFORM="apollolake"
    elif [ "${MODEL}" = "DS3615xs" ]; then
        TARGET_PLATFORM="bromolow"
    elif [ "${MODEL}" = "DS3617xs" ]; then
        TARGET_PLATFORM="broadwell"
    elif [ "${MODEL}" = "DS3622xs+" ]; then
        TARGET_PLATFORM="broadwellnk"
    elif [ "${MODEL}" = "DS1621+" ]; then
        TARGET_PLATFORM="v1000"
    elif [ "${MODEL}" = "DVA3221" ]; then
        TARGET_PLATFORM="denverton"
    elif [ "${MODEL}" = "DS920+" ]; then
        TARGET_PLATFORM="geminilake"
    fi

echo TARGET_PLATFORM is $TARGET_PLATFORM

./rploader.sh update now
./rploader.sh fullupgrade now

./rploader.sh serialgen $MODEL
./rploader.sh identifyusb now
./rploader.sh satamap now

echo Loader Building in progress... 

./rploader.sh build ${TARGET_PLATFORM}-7.1.0-42661

echo Backup in progress...   

rm -rf /home/tc/old; 
rm -rf /home/tc/oldpat.tar.gz;
./rploader.sh clean now;  
rm -rf /mnt/${tcrppart}/auxfiles;  
rm -rf /home/tc/custom-module;  
./rploader.sh backup now;

