#!/bin/bash

# m.sh (Batch Shell Script for rploader.sh)                 
# Made by Peter Suh
# 2022.04.18                      
# Update add 42661 U1 NanoPacked 
# 2022.04.28
# Update : add noconfig, noclean, manual options
# 2022.04.30
# Update : add noconfig, noclean, manual combinatione options 
# 2022.05.06

mshellgz="m.sh.gz"
mshtarfile="https://raw.githubusercontent.com/PeterSuh-Q3/tinycore-redpill/main/m.sh.gz"

# Function cecho                                                                                        
# Made by FOXBI                                                                                                               
# 2022.04.14                                                                                                                  
# ==============================================================================          
# Color Function                                                                          
# ==============================================================================          
cecho () {                                                                                
    if [ -n "$3" ]                                                                                                            
    then                                                                                  
        case "$3" in                                                                                 
            black  | bk) bgcolor="40";;                                                              
            red    |  r) bgcolor="41";;                                                              
            green  |  g) bgcolor="42";;                                                                 
            yellow |  y) bgcolor="43";;                                             
            blue   |  b) bgcolor="44";;                                             
            purple |  p) bgcolor="45";;                                                   
            cyan   |  c) bgcolor="46";;                                             
            gray   | gr) bgcolor="47";;                                             
        esac                                                                        
    else                                                                            
        bgcolor="0"                                                                 
    fi                                                                              
    code="\033["                                                                    
    case "$1" in                                                                    
        black  | bk) color="${code}${bgcolor};30m";;                                
        red    |  r) color="${code}${bgcolor};31m";;                                
        green  |  g) color="${code}${bgcolor};32m";;                                
        yellow |  y) color="${code}${bgcolor};33m";;                                
        blue   |  b) color="${code}${bgcolor};34m";;                                
        purple |  p) color="${code}${bgcolor};35m";;                                
        cyan   |  c) color="${code}${bgcolor};36m";;                                
        gray   | gr) color="${code}${bgcolor};37m";;                                
    esac                                                                            
                                                                                                                                                                    
    text="$color$2${code}0m"                                                                                                                                        
    echo -e "$text"                                                                                                                                                 
}   


function checkinternet() {

    echo -n "Checking Internet Access -> "
    nslookup github.com 2>&1 >/dev/null
    if [ $? -eq 0 ]; then
        echo "OK"
    else
        cecho g "Error: No internet found, or github is not accessible"
        exit 99
    fi

}

function getlatestmshell() {

    echo -n "Checking if a newer mshell version exists on the repo -> "

    if [ ! -f $mshellgz ]; then
        curl -s --location "$mshtarfile" --output $mshellgz
    fi

    curl -s --location "$mshtarfile" --output latest.mshell.gz

    CURRENTSHA="$(sha256sum $mshellgz | awk '{print $1}')"
    REPOSHA="$(sha256sum latest.mshell.gz | awk '{print $1}')"

    if [ "${CURRENTSHA}" != "${REPOSHA}" ]; then
        echo -n "There is a newer version of m shell script on the repo should we use that ? [yY/nN]"
        read confirmation
        if [ "$confirmation" = "y" ] || [ "$confirmation" = "Y" ]; then
            echo "OK, updating, please re-run after updating"
            cp -f /home/tc/latest.mshell.gz /home/tc/$mshellgz
            rm -f /home/tc/latest.mshell.gz
            tar -zxvf $mshellgz
            echo "Updating m shell with latest updates"
            exit
        else
            rm -f /home/tc/latest.mshell.gz
            return
        fi
    else
        echo "Version is current"
        rm -f /home/tc/latest.mshell.gz
    fi

}


function macgen() {

    mac2="$(generateMacAddress $1)"

    cecho y "Mac2 Address for Model $1 : $mac2 "

    macaddress2=$(echo $mac2 | sed -s 's/://g')

    sed -i "/\"extra_cmdline\": {/c\  \"extra_cmdline\": {\"mac2\": \"$macaddress2\",\"netif_num\": \"2\", "  user_config.json

    echo "After changing user_config.json"      
    cat user_config.json

}

function generateMacAddress() {
    printf '00:11:32:%02X:%02X:%02X' $((RANDOM % 256)) $((RANDOM % 256)) $((RANDOM % 256))

}

function showhelp() {
    cat <<EOF
$(basename ${0})

----------------------------------------------------------------------------------------
Usage: ${0} <Synology Model Name> <Options>

Options: noconfig, noclean, manual

- noconfig: SKIP automatic detection change processing such as SN/Mac/Vid/Pid/SataPortMap of user_config.json file.

- noclean: SKIP the 💊   RedPill LKM/LOAD directory without clearing it with the Clean now command. 
           However, delete the Cache directory and loader.img.

- manual: Options for manual extension processing and manual dtc processing in build action (skipping extension auto detection) 


Please type Synology Model Name after ./$(basename ${0})

./$(basename ${0}) DS918+
./$(basename ${0}) DS3617xs
./$(basename ${0}) DS3615xs
./$(basename ${0}) DS3622xs+
./$(basename ${0}) DVA3221
./$(basename ${0}) DS920+
./$(basename ${0}) DS1621+

EOF

}


if [ $# -lt 1 ]; then
    showhelp 
    exit 99
fi

MODEL=$1

echo ""
cecho y "MODEL is $MODEL"

TARGET_REVISION="42661"

    if [ "${MODEL}" = "DS918+" ]; then
        TARGET_PLATFORM="apollolake"
        SYNOMODEL="ds918p_$TARGET_REVISION"
    elif [ "${MODEL}" = "DS3615xs" ]; then
        TARGET_PLATFORM="bromolow"
        SYNOMODEL="ds3615xs_$TARGET_REVISION"
    elif [ "${MODEL}" = "DS3617xs" ]; then
        TARGET_PLATFORM="broadwell"
        SYNOMODEL="ds3617xs_$TARGET_REVISION"
    elif [ "${MODEL}" = "DS3622xs+" ]; then
        TARGET_PLATFORM="broadwellnk"
        SYNOMODEL="ds3622xsp_$TARGET_REVISION"
    elif [ "${MODEL}" = "DS1621+" ]; then
        TARGET_PLATFORM="v1000"
        SYNOMODEL="ds1621p_$TARGET_REVISION"
    elif [ "${MODEL}" = "DVA3221" ]; then
        TARGET_PLATFORM="denverton"
        SYNOMODEL="dva3221_$TARGET_REVISION"
    elif [ "${MODEL}" = "DS920+" ]; then
        TARGET_PLATFORM="geminilake"
        SYNOMODEL="ds920p_$TARGET_REVISION"
    else
        echo "Synology model not supported by TCRP."                                                                                                                                                                           
        exit 0  
    fi

checkinternet
getlatestmshell

tcrppart="$(mount | grep -i optional | grep cde | awk -F / '{print $3}' | uniq | cut -c 1-3)3"
echo ""
echo tcrppart is $tcrppart                                                  
echo ""
cecho g "making directory  /mnt/${tcrppart}/auxfiles and make link custom-module"
mkdir /mnt/${tcrppart}/auxfiles                                             
sudo ln -s /mnt/${tcrppart}/auxfiles /home/tc/custom-module 

echo ""
cecho y "TARGET_PLATFORM is $TARGET_PLATFORM"

echo "y"|./rploader.sh update now
echo "n"|./rploader.sh fullupgrade now

cecho y "Do you want to restore your own user_config.json from old directory ?  [Yy/Nn]"
read answer                                                                         
if [ -n "$answer" ] && [ "$answer" = "Y" ] || [ "$answer" = "y" ] ; then            
    cp -f /home/tc/old/user_config.json.* ./user_config.json
else                                                                                
    echo "OK Remember that the new user_config.json file is used and your own user_config.json is deleted. "        
fi 

if [ "$2" == "noconfig" ] || [ "$3" == "noconfig" ] || [ "$4" == "noconfig" ] ; then 
    cecho r "SN Gen/Mac Gen/Vid/Pid/SataPortMap detection skipped!!" 
else
    echo "Before changing user_config.json" 
    cat user_config.json

    ./rploader.sh serialgen $MODEL

    #check nic count
    let nicport=0                                                                                                                                                 
    lspci -n | while read line; do                                                                                                                  
        class="$(echo $line | cut -c 9-12)"                                                                                                          
                                                                                                                                                     
        #echo "Class : $class"                                                                             
        case $class in                                                                                                                               
        0200)   
            let nicport=$nicport+1                                                                                                                                     
            #echo "Found Ethernet Interface port count: $nicport "       
            if [ $nicport -eq 2 ]; then
               cecho g "Two or more Ethernet Interface was detected!! $nicport "
               cecho g "Add mac2 automatically."
               macgen $MODEL
            fi                                                     
      
            ;;                                                                                                                                       
        esac                                                                                                                                         
    done 

    ./rploader.sh identifyusb now
    ./rploader.sh satamap now
fi


echo ""
echo ""
cecho p "DSM PAT file pre-downloading in progress..."
URL="https://global.download.synology.com/download/DSM/release/7.1/42661-1/DSM_${MODEL}_$TARGET_REVISION.pat"
cecho y "$URL"

    if [ -f /mnt/${tcrppart}/auxfiles/${SYNOMODEL}.pat ]; then
        cecho r "Found locally cached pat file ${SYNOMODEL}.pat in /mnt/${tcrppart}/auxfiles"  
        cecho b "Downloadng Skipped!!!"
    else
        curl -o /mnt/${tcrppart}/auxfiles/${SYNOMODEL}.pat $URL 

    fi

echo ""
cecho g "Loader Building in progress..."
echo ""

if [ "$2" == "manual" ] || [ "$3" == "manual" ] || [ "$4" == "manual" ] ; then 
    cecho r "Loader Manual Building in progress..."   
    ./rploader.sh build ${TARGET_PLATFORM}-7.1.0-42661 manual
else
    ./rploader.sh build ${TARGET_PLATFORM}-7.1.0-42661
fi                                                                                                                

echo ""                                                                                                                                                                           
cecho y "Backup in progress..."                                                                                                                                                
echo ""
                                                                                                                                                                           
rm -rf /home/tc/old                                                                                                                                                       
rm -rf /home/tc/oldpat.tar.gz                                                                                                                                             
if [ "$2" == "noclean" ] || [ "$3" == "noclean" ] || [ "$4" == "noclean" ] ; then
    cecho r "Cleaning redpill-load directory and pat files in auxfiles directory skipped!!!"   
    rm -f /home/tc/redpill-load/cache/*                                                                      
    rm -f /home/tc/redpill-load/loader.img    
else
    ./rploader.sh clean now                                                                                  
    rm -f /mnt/${tcrppart}/auxfiles/*.pat   
fi    
rm -f /home/tc/custom-module                                                                                                                                             
echo "y"|./rploader.sh backup now                                                                                                                                         
                                          

exit 0
