#!/bin/bash

# 
# Made by Peter Suh
# 2022.04.19
#
function macgen() {

    mac2="$(generateMacAddress $1)"

    echo "Mac2 Address for Model $1 : $mac2 "

    macaddress2=$(echo $mac2 | sed -s 's/://g')

    sed -i "/\"extra_cmdline\": {/c\  \"extra_cmdline\": {\"mac2\": \"$macaddress2\",\"netif_num\": \"2\", "  user_config.json
    
    cat user_config.json

}

function generateMacAddress() {
    printf '00:11:32:%02X:%02X:%02X' $((RANDOM % 256)) $((RANDOM % 256)) $((RANDOM % 256))

}


# Function EXDRIVER_FN#
# Made by FOXBI
# 2022.04.14
#
# ==============================================================================
# Y or N Function
# ==============================================================================
READ_YN () { # $1:question $2:default
   read -n1 -p "$1" Y_N
    case "$Y_N" in
    y) Y_N="y"
         echo -e "\n" ;;
    n) Y_N="n"
         echo -e "\n" ;;        
    q) echo -e "\n"
       exit 0 ;;
    *) echo -e "\n" ;;
    esac
}
# ==============================================================================
# Color Function
# ==============================================================================
cecho () {
    if [ -n "$3" ]
    then
        case "$3" in
            black  | bk) bgcolor="40";;
            red    |  r) bgcolor="41";;
            green  |  g) bgcolor="42";;
            yellow |  y) bgcolor="43";;
            blue   |  b) bgcolor="44";;
            purple |  p) bgcolor="45";;
            cyan   |  c) bgcolor="46";;
            gray   | gr) bgcolor="47";;
        esac        
    else
        bgcolor="0"
    fi
    code="\033["
    case "$1" in
        black  | bk) color="${code}${bgcolor};30m";;
        red    |  r) color="${code}${bgcolor};31m";;
        green  |  g) color="${code}${bgcolor};32m";;
        yellow |  y) color="${code}${bgcolor};33m";;
        blue   |  b) color="${code}${bgcolor};34m";;
        purple |  p) color="${code}${bgcolor};35m";;
        cyan   |  c) color="${code}${bgcolor};36m";;
        gray   | gr) color="${code}${bgcolor};37m";;
    esac

    text="$color$2${code}0m"
    echo -e "$text"
}
# ==============================================================================
# Extension Driver Function
# ==============================================================================
function EXDRIVER_FN() {

    # ==============================================================================
    # Clear extension & install extension driver
    # ==============================================================================
    echo ""
    cecho c "Delete extension file..."
    sudo rm -rf ./redpill-load/custom/extensions/*
    echo ""
    cecho c "Update ext-manager..."
    ./redpill-load/ext-manager.sh update

    echo ""    
    cecho r "Add to Driver Repository..."
    echo ""
    READ_YN "Do you want Add Driver? Y/N :  "
    ICHK=$Y_N
    while [ "$ICHK" == "y" ] || [ "$ICHK" == "Y" ]
    do
        ICNT=
        JCNT=
        IRRAY=()
        while read LINE_I;
        do
            ICNT=$(($ICNT + 1))
            JCNT=$(($ICNT%5))
            if [ "$JCNT" -eq "0" ]
            then
                IRRAY+=("$ICNT) $LINE_I\ln");
            else
                IRRAY+=("$ICNT) $LINE_I\lt");
            fi
        done < <(curl --no-progress-meter https://github.com/pocopico/rp-ext | grep "raw.githubusercontent.com" | awk '{print $2}' | awk -F= '{print $2}' | sed "s/\"//g" | awk -F/ '{print $7}')
            echo ""
            echo -e " ${IRRAY[@]}" | sed 's/\\ln/\n/g' | sed 's/\\lt/\t/g'
            echo ""
            read -n100 -p " -> Select Number Enter (To select multiple, separate them with , ): " I_O
            echo ""
            I_OCHK=`echo $I_O | grep , | wc -l`
            if [ "$I_OCHK" -gt "0" ]
            then
                while read LINE_J;
                do
                    j=$((LINE_J - 1))
                    IEXT=`echo "${IRRAY[$j]}" | sed 's/\\\ln//g' | sed 's/\\\lt//g' | awk '{print $2}'`
                    ./rploader.sh ext ${TARGET_PLATFORM}-7.1.0-42661 add https://raw.githubusercontent.com/pocopico/rp-ext/master/$IEXT/rpext-index.json
                done < <(echo $I_O | tr ',' '\n')
            else
                I_O=$(($I_O - 1))
                for (( i = 0; i < $ICNT; i++)); do
                    if [ "$I_O" == $i ]
                    then
                        export IEXT=`echo "${IRRAY[$i]}" | sed 's/\\\ln//g' | sed 's/\\\lt//g' | awk '{print $2}'`
                    fi
                done
                ./rploader.sh ext ${TARGET_PLATFORM}-7.1.0-42661 add https://raw.githubusercontent.com/pocopico/rp-ext/master/$IEXT/rpext-index.json
            fi
        echo ""
        READ_YN "Do you want add driver? Y/N :  "
        ICHK=$Y_N
    done
}



if [ $# -lt 1 ]; then
    echo Please type Synology Model Name after ./m.sh
    exit 99
fi

MODEL=$1

echo MODEL is $MODEL

    if [ "${MODEL}" = "DS918+" ]; then
        TARGET_PLATFORM="apollolake"
    elif [ "${MODEL}" = "DS3615xs" ]; then
        TARGET_PLATFORM="bromolow"
    elif [ "${MODEL}" = "DS3617xs" ]; then
        TARGET_PLATFORM="broadwell"
    elif [ "${MODEL}" = "DS3622xs+" ]; then
        TARGET_PLATFORM="broadwellnk"
    elif [ "${MODEL}" = "DS1621+" ]; then
        TARGET_PLATFORM="v1000"
    elif [ "${MODEL}" = "DVA3221" ]; then
        TARGET_PLATFORM="denverton"
    elif [ "${MODEL}" = "DS920+" ]; then
        TARGET_PLATFORM="geminilake"
    else
        echo "Synology model not supported by TCRP."
        exit 0
    fi


tcrppart="$(mount | grep -i optional | grep cde | awk -F / '{print $3}' | uniq | cut -c 1-3)3"
echo tcrppart is $tcrppart                                                  
echo making directory  /mnt/${tcrppart}/auxfiles and make link custom-module                                                  
mkdir /mnt/${tcrppart}/auxfiles                                             
sudo ln -s /mnt/${tcrppart}/auxfiles /home/tc/custom-module 

echo TARGET_PLATFORM is $TARGET_PLATFORM

echo "y"|./rploader.sh update now
echo "y"|./rploader.sh fullupgrade now

echo "Do you want to restore your own user_config.json from old directory ?  [Yy/Nn]"         
read answer                                                                                   
if [ -n "$answer" ] && [ "$answer" = "Y" ] || [ "$answer" = "y" ] ; then                      
    cp -f /home/tc/old/user_config.json.* ./user_config.json                                  
else                                                                                          
    echo "OK Remember that the new user_config.json file is used and your own user_config.json is deleted. "
fi  

echo "y"| ./rploader.sh serialgen $MODEL

echo "Do you want to add mac2 value ?  [Yy/Nn]"                                                                                                                
read answer                                                                                                                                                    
if [ -n "$answer" ] && [ "$answer" = "Y" ] || [ "$answer" = "y" ] ; then                                                                                       
    macgen $MODEL                                                                                                                                                                       
else                                                                                                                                                           
    echo "OK remember to add mac2 manually by editing user_config.json file"                                                                                   
fi   

echo Adding Ext in progress...

EXDRIVER_FN

echo Loader Building in progress...

echo "y"|./rploader.sh build ${TARGET_PLATFORM}-7.1.0-42661                                                                                                                
                                                                                                                                                                           
echo Backup in progress...                                                                                                                                                 
                                                                                                                                                                           
rm -rf /home/tc/old                                                                                                                                                       
rm -rf /home/tc/oldpat.tar.gz                                                                                                                                             
./rploader.sh clean now                                                                                                                                                   
rm -f /mnt/${tcrppart}/auxfiles/*.pat                                                                                                                                          
rm -f /home/tc/custom-module                                                                                                                                             
echo "y"|./rploader.sh backup now                                                                                                                                         
                                          

exit 0
